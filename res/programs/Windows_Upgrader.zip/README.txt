This malware was a quickly put together project made by GeneralTechyBoi.
------------------------------------------------------------------------
There are two .exe's in this folder:

setup.exe (For Windows Vista or newer)
xpsetup.exe (For Windows XP)
------------------------------------------------------------------------
Have fun testing out this malware, and remember, only run it in a
virtual machine, not your real machine as it can overwrite the MBR.